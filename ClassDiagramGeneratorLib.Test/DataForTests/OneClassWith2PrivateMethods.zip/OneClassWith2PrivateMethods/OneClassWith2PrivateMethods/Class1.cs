﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OneClassWith2PrivateMethods
{
    public class Class1
    {
        private void Method1() { }

        private string Method2()
        {
            return "hello";
        }
    }
}
