﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OneClass2PrivatesAttributes
{
    public class Class1
    {
        private int _attribute1;
        private string _attribute2;
    }
}
