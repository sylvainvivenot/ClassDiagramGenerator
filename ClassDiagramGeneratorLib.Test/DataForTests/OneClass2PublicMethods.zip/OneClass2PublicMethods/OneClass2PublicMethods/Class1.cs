﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OneClass2PublicMethods
{
    public class Class1
    {
        public void Method1()
        {
            
        }

        public string Method2()
        {
            return "hello";
        }
    }
}
