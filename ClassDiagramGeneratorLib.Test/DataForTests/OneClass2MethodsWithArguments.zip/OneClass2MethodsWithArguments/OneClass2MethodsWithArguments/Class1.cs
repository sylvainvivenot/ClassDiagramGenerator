﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OneClass2MethodsWithArguments
{
    public class Class1
    {
        public void Method1(int a)
        {
            
        }

        public string Method2(string a, string b)
        {
            return a + b;
        }
    }
}
