﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class1UsedInClass2
{
    public class Class2
    {
        private Class1 _instance1;

        public Class2(Class1 instance1)
        {
            _instance1 = instance1;
        }
    }
}
