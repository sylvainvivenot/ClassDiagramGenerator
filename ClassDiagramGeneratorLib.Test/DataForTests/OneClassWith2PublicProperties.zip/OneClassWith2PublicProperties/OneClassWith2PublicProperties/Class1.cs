﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OneClassWith2PublicProperties
{
    public class Class1
    {
        public int Property1 { get; set; }
        public string Property2 { get; set; }
    }
}
