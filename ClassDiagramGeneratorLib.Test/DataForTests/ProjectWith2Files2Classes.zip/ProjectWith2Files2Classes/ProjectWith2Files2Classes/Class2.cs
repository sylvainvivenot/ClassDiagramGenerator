﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectWith2Files2Classes
{
    class Class2
    {
    }
}
