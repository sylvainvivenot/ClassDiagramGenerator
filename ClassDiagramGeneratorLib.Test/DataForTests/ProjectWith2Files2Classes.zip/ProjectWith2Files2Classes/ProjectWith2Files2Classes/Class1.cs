﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectWith2Files2Classes
{
    public class Class1
    {
    }
}
